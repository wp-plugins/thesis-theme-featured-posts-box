RoaRender Digital Design Firm
www.roarender.com 2011
josh@roarender.com
rainier@roarender.com

RoaRender-FeaturedBox Plugin Requirements:

ThesisTheme should be installed for the plugin to work.

Description:
Displays an animated �Featured Box� on the home page that contains the featured posts category.  

Customize the number of posts to display, animation speed, and customize the font, background, border colors as well as the size of the featured box without touching any CSS file using the plugin's admin panel.

Installation:
1.Under the wp-admin dashboard, click on the Plugins menu dropdown and then click on �Add new�.
2.Click on the �Upload� link on the top.
3.Click on the Browse button and locate the �roarender-featuredbox.zip� and then click �Install Now�.
4.Activate the plugin.
5.Click on the Settings menu dropdown, and click on the �RoaRender Featured Box� for the plugin's settings.